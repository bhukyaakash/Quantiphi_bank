/**
 * Backend Implementation: Bank Transaction Parser & Categorizer
 * Framework: Node.js + Express
 * Purpose: Provides REST API for transaction processing and analytics
 */

// ==================== DEPENDENCIES ====================
// npm install express mongoose cors dotenv
const express = require('express');
const router = express.Router();

// ==================== MERCHANT KEYWORDS DATABASE ====================
const merchantKeywords = {
  'Food & Dining': [
    'zomato', 'swiggy', 'dominos', 'kfc', 'mcdonalds',
    'pizza hut', 'subway', 'cafe', 'restaurant', 'food',
    'biryani', 'chinese', 'bakery', 'juice', 'dosa'
  ],
  'Travel': [
    'uber', 'ola', 'redbus', 'goibibo', 'make my trip',
    'irctc', 'airline', 'flight', 'taxi', 'transit',
    'train', 'bus', 'metro', 'auto', 'cab'
  ],
  'Salary': [
    'salary', 'payroll', 'wages', 'stipend', 'income',
    'bonus', 'commission', 'payment', 'deposit'
  ],
  'Shopping': [
    'amazon', 'flipkart', 'myntra', 'ajio', 'ebay',
    'mall', 'store', 'shop', 'retail', 'clothing',
    'electronics', 'books', 'shoes'
  ],
  'Utilities': [
    'electricity', 'water', 'gas', 'internet', 'phone',
    'mobile', 'bill', 'subscription', 'netflix', 'spotify'
  ],
  'Healthcare': [
    'hospital', 'doctor', 'pharmacy', 'medical', 'clinic',
    'medicine', 'dentist', 'health', 'apollo', 'fortis'
  ]
};

// Known reward partners for cashback detection
const rewardPartners = [
  'amazon', 'flipkart', 'swiggy', 'zomato', 'uber',
  'make my trip', 'myntra', 'netflix', 'spotify'
];

// ==================== TRANSACTION PARSER ====================
/**
 * Parses raw transaction alert text and extracts key information
 * @param {string} rawText - Raw transaction message
 * @returns {object} Parsed transaction object
 */
function parseTransactionText(rawText) {
  const text = rawText.trim();
  
  // Extract amount using regex
  const amountMatch = text.match(/Rs\.?\s*[\d,]+/i);
  let amount = 0;
  if (amountMatch) {
    amount = parseInt(amountMatch[0].replace(/Rs\.?|,/g, ''));
  }
  
  // Determine transaction type (received vs paid)
  const isReceived = /received|credited|incoming|deposit/i.test(text);
  const isPaid = /paid|spent|debited|outgoing/i.test(text);
  
  // Apply sign to amount
  if (isPaid) {
    amount = -Math.abs(amount);
  } else if (isReceived) {
    amount = Math.abs(amount);
  }
  
  return {
    description: text,
    amount: amount,
    timestamp: new Date(),
    isReceived: isReceived,
    isPaid: isPaid,
    rawAmount: amountMatch ? amountMatch[0] : 'N/A'
  };
}

// ==================== AUTO-CATEGORIZER ====================
/**
 * Automatically categorizes transaction based on merchant keywords
 * @param {string} description - Transaction description
 * @returns {string} Assigned category
 */
function categorizeTransaction(description) {
  const lowerDesc = description.toLowerCase();
  
  // Search through keyword database
  for (const [category, keywords] of Object.entries(merchantKeywords)) {
    for (const keyword of keywords) {
      if (lowerDesc.includes(keyword)) {
        return category;
      }
    }
  }
  
  // Default fallback for unmatched transactions
  return 'Miscellaneous';
}

// ==================== CASHBACK DETECTOR ====================
/**
 * Detects if transaction qualifies for rewards/cashback
 * @param {string} description - Transaction description
 * @param {number} amount - Transaction amount
 * @returns {object} Cashback detection result
 */
function detectCashback(description, amount) {
  const lowerDesc = description.toLowerCase();
  
  // Only process outgoing transactions
  if (amount >= 0) {
    return { hasCashback: false, savingsAmount: 0, partner: null };
  }
  
  // Check for explicit cashback keyword
  const hasCashbackKeyword = lowerDesc.includes('cashback');
  
  // Check if merchant is a reward partner
  let matchedPartner = null;
  for (const partner of rewardPartners) {
    if (lowerDesc.includes(partner)) {
      matchedPartner = partner;
      break;
    }
  }
  
  // Calculate expected savings
  if (hasCashbackKeyword || matchedPartner) {
    // Base calculation: 1-5% of transaction amount
    const basePercentage = Math.random() * 4 + 1; // 1-5%
    const savingsAmount = Math.round((Math.abs(amount) * basePercentage) / 100);
    
    return {
      hasCashback: true,
      savingsAmount: Math.max(savingsAmount, 10), // Min Rs. 10
      partner: matchedPartner,
      estimatedPercentage: basePercentage.toFixed(2)
    };
  }
  
  return { hasCashback: false, savingsAmount: 0, partner: null };
}

// ==================== METRICS REDUCER ====================
/**
 * Accumulates metrics across multiple transactions
 * @param {array} transactions - Array of transaction objects
 * @returns {object} Aggregated metrics by category
 */
function calculateMetrics(transactions) {
  const metrics = {};
  
  // Initialize all categories
  Object.keys(merchantKeywords).forEach(category => {
    metrics[category] = {
      total: 0,
      count: 0,
      outgoingCount: 0,
      incomingCount: 0,
      incomingTotal: 0,
      transactions: []
    };
  });
  
  // Also add Miscellaneous
  metrics['Miscellaneous'] = {
    total: 0,
    count: 0,
    outgoingCount: 0,
    incomingCount: 0,
    incomingTotal: 0,
    transactions: []
  };
  
  // Process each transaction
  transactions.forEach(tx => {
    const category = tx.customCategory || tx.category;
    
    if (metrics[category]) {
      metrics[category].count += 1;
      
      if (tx.amount < 0) {
        // Outgoing expense
        metrics[category].total += Math.abs(tx.amount);
        metrics[category].outgoingCount += 1;
      } else if (tx.amount > 0) {
        // Incoming income
        metrics[category].incomingCount += 1;
        metrics[category].incomingTotal += tx.amount;
      }
      
      metrics[category].transactions.push({
        id: tx.id,
        amount: tx.amount,
        description: tx.description
      });
    }
  });
  
  return metrics;
}

// ==================== REST API ENDPOINTS ====================

/**
 * POST /api/transactions/parse
 * Parse raw transaction text and return categorized transaction
 */
router.post('/transactions/parse', (req, res) => {
  try {
    const { rawText } = req.body;
    
    if (!rawText) {
      return res.status(400).json({ error: 'rawText is required' });
    }
    
    // Parse transaction text
    const parsed = parseTransactionText(rawText);
    
    // Auto-categorize
    const category = categorizeTransaction(parsed.description);
    
    // Detect cashback
    const cashback = detectCashback(parsed.description, parsed.amount);
    
    // Return complete transaction object
    res.json({
      success: true,
      transaction: {
        description: parsed.description,
        amount: parsed.amount,
        category: category,
        timestamp: parsed.timestamp,
        hasCashback: cashback.hasCashback,
        savingsAmount: cashback.savingsAmount,
        rewardPartner: cashback.partner,
        estimatedCashbackPercentage: cashback.estimatedPercentage
      }
    });
  } catch (error) {
    res.status(500).json({ 
      error: 'Failed to parse transaction',
      message: error.message 
    });
  }
});

/**
 * POST /api/transactions/batch
 * Process multiple transaction alerts at once
 */
router.post('/transactions/batch', (req, res) => {
  try {
    const { transactions } = req.body;
    
    if (!Array.isArray(transactions)) {
      return res.status(400).json({ error: 'transactions must be an array' });
    }
    
    const processed = transactions.map((rawText, idx) => {
      const parsed = parseTransactionText(rawText);
      const category = categorizeTransaction(parsed.description);
      const cashback = detectCashback(parsed.description, parsed.amount);
      
      return {
        id: idx + 1,
        ...parsed,
        category: category,
        hasCashback: cashback.hasCashback,
        savingsAmount: cashback.savingsAmount
      };
    });
    
    res.json({
      success: true,
      processed: processed.length,
      transactions: processed
    });
  } catch (error) {
    res.status(500).json({ 
      error: 'Failed to batch process transactions',
      message: error.message 
    });
  }
});

/**
 * POST /api/metrics/calculate
 * Calculate spending metrics from transaction list
 */
router.post('/metrics/calculate', (req, res) => {
  try {
    const { transactions } = req.body;
    
    if (!Array.isArray(transactions)) {
      return res.status(400).json({ error: 'transactions must be an array' });
    }
    
    const metrics = calculateMetrics(transactions);
    
    // Calculate aggregate stats
    const totalSpending = Object.values(metrics)
      .reduce((sum, cat) => sum + cat.total, 0);
    
    const totalIncome = Object.values(metrics)
      .reduce((sum, cat) => sum + cat.incomingTotal, 0);
    
    const netCashFlow = totalIncome - totalSpending;
    
    // Find top spending category
    let topCategory = null;
    let maxSpending = 0;
    Object.entries(metrics).forEach(([category, data]) => {
      if (data.total > maxSpending) {
        maxSpending = data.total;
        topCategory = category;
      }
    });
    
    res.json({
      success: true,
      metrics: metrics,
      summary: {
        totalSpending: totalSpending,
        totalIncome: totalIncome,
        netCashFlow: netCashFlow,
        topCategory: topCategory,
        transactionCount: transactions.length,
        averageTransaction: totalSpending / transactions.length
      }
    });
  } catch (error) {
    res.status(500).json({ 
      error: 'Failed to calculate metrics',
      message: error.message 
    });
  }
});

/**
 * GET /api/merchants
 * Get all merchants and their categories
 */
router.get('/merchants', (req, res) => {
  const merchants = {};
  Object.entries(merchantKeywords).forEach(([category, keywords]) => {
    merchants[category] = keywords;
  });
  
  res.json({
    success: true,
    merchants: merchants,
    totalKeywords: Object.values(merchantKeywords)
      .reduce((sum, arr) => sum + arr.length, 0)
  });
});

/**
 * GET /api/merchants/:category
 * Get merchants for a specific category
 */
router.get('/merchants/:category', (req, res) => {
  const { category } = req.params;
  
  if (!merchantKeywords[category]) {
    return res.status(404).json({ 
      error: 'Category not found',
      availableCategories: Object.keys(merchantKeywords)
    });
  }
  
  res.json({
    success: true,
    category: category,
    merchants: merchantKeywords[category]
  });
});

/**
 * POST /api/merchants/add
 * Add new merchant keyword (admin only)
 */
router.post('/merchants/add', (req, res) => {
  const { category, merchant } = req.body;
  
  if (!category || !merchant) {
    return res.status(400).json({ 
      error: 'category and merchant are required' 
    });
  }
  
  if (!merchantKeywords[category]) {
    return res.status(404).json({ 
      error: 'Category not found' 
    });
  }
  
  const lowerMerchant = merchant.toLowerCase();
  
  if (merchantKeywords[category].includes(lowerMerchant)) {
    return res.status(400).json({ 
      error: 'Merchant already exists in this category' 
    });
  }
  
  merchantKeywords[category].push(lowerMerchant);
  
  res.json({
    success: true,
    message: `Added ${merchant} to ${category}`,
    category: category,
    merchants: merchantKeywords[category]
  });
});

/**
 * POST /api/analytics/insights
 * Generate spending insights and recommendations
 */
router.post('/analytics/insights', (req, res) => {
  try {
    const { transactions } = req.body;
    
    if (!Array.isArray(transactions)) {
      return res.status(400).json({ error: 'transactions must be an array' });
    }
    
    const metrics = calculateMetrics(transactions);
    
    // Generate insights
    const insights = [];
    
    // High spending detection
    Object.entries(metrics).forEach(([category, data]) => {
      if (data.total > 5000) {
        insights.push({
          type: 'high_spending',
          category: category,
          amount: data.total,
          message: `High spending detected in ${category}: Rs. ${data.total}`
        });
      }
    });
    
    // Savings opportunity detection
    const savingsTransactions = transactions.filter(t => t.hasCashback);
    if (savingsTransactions.length > 0) {
      const totalSavings = savingsTransactions.reduce((sum, t) => sum + t.savingsAmount, 0);
      insights.push({
        type: 'savings_opportunity',
        amount: totalSavings,
        transactionCount: savingsTransactions.length,
        message: `Potential savings of Rs. ${totalSavings} from cashback`
      });
    }
    
    // Recurring merchant detection
    const merchantFrequency = {};
    transactions.forEach(t => {
      const merchant = t.description.split('to ')[1] || t.description;
      merchantFrequency[merchant] = (merchantFrequency[merchant] || 0) + 1;
    });
    
    Object.entries(merchantFrequency).forEach(([merchant, count]) => {
      if (count >= 3) {
        insights.push({
          type: 'recurring_merchant',
          merchant: merchant,
          count: count,
          message: `Frequent merchant: ${merchant} (${count} transactions)`
        });
      }
    });
    
    res.json({
      success: true,
      insights: insights,
      insightCount: insights.length
    });
  } catch (error) {
    res.status(500).json({ 
      error: 'Failed to generate insights',
      message: error.message 
    });
  }
});

// ==================== EXPORT ====================
module.exports = router;

/**
 * USAGE IN MAIN EXPRESS APP:
 * 
 * const express = require('express');
 * const transactionRoutes = require('./transactions');
 * 
 * const app = express();
 * app.use(express.json());
 * app.use('/api', transactionRoutes);
 * 
 * app.listen(3000, () => console.log('Server running on port 3000'));
 */

/**
 * EXAMPLE API CALLS:
 * 
 * 1. Parse single transaction:
 *    POST /api/transactions/parse
 *    Body: { "rawText": "Paid Rs. 850 to Zomato" }
 * 
 * 2. Batch process multiple transactions:
 *    POST /api/transactions/batch
 *    Body: { "transactions": ["Paid Rs. 850 to Zomato", "Paid Rs. 1200 to Uber"] }
 * 
 * 3. Calculate metrics:
 *    POST /api/metrics/calculate
 *    Body: { "transactions": [{...}, {...}] }
 * 
 * 4. Get all merchants:
 *    GET /api/merchants
 * 
 * 5. Add new merchant:
 *    POST /api/merchants/add
 *    Body: { "category": "Food & Dining", "merchant": "dominos" }
 * 
 * 6. Generate insights:
 *    POST /api/analytics/insights
 *    Body: { "transactions": [{...}, {...}] }
 */
