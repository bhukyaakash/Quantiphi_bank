# Bank Transaction Manager - Deployment & Setup Guide

## 📦 Technology Stack

### Frontend
- **React 18+** - UI framework
- **CSS Variables** - Theme styling
- **fetch API** - HTTP communication

### Backend
- **Node.js 18+** - Runtime
- **Express.js** - REST API framework
- **MongoDB** - NoSQL database
- **Mongoose** - ODM library

### Infrastructure
- **Docker** - Containerization
- **Docker Compose** - Multi-container orchestration
- **Nginx** - Reverse proxy
- **Redis** - Caching layer (optional)

---

## 🚀 Quick Start (Development)

### Prerequisites
```bash
Node.js v18+
MongoDB (local or Atlas)
npm or yarn
```

### 1. Clone Repository
```bash
git clone <repository-url>
cd bank-transaction-manager
```

### 2. Backend Setup
```bash
cd backend
npm install

# Create .env file
cat > .env << EOF
MONGODB_URI=mongodb://localhost:27017/bankmanager
PORT=3000
NODE_ENV=development
JWT_SECRET=your-secret-key-here
CORS_ORIGIN=http://localhost:3001
EOF

npm start
# Server runs on http://localhost:3000
```

### 3. Frontend Setup
```bash
cd frontend
npm install

# Create .env file
cat > .env << EOF
REACT_APP_API_URL=http://localhost:3000/api
REACT_APP_ENV=development
EOF

npm start
# App opens on http://localhost:3001
```

---

## 🐳 Docker Deployment

### Build Docker Images

#### Backend Dockerfile
```dockerfile
FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy application code
COPY . .

# Expose port
EXPOSE 3000

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
  CMD node -e "require('http').get('http://localhost:3000/health', (r) => {if (r.statusCode !== 200) throw new Error(r.statusCode)})"

# Start application
CMD ["npm", "start"]
```

#### Frontend Dockerfile
```dockerfile
FROM node:18-alpine as builder

WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/build /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### Docker Compose
```yaml
version: '3.8'

services:
  mongodb:
    image: mongo:6.0
    container_name: bankmanager-db
    ports:
      - "27017:27017"
    volumes:
      - mongo_data:/data/db
    environment:
      MONGO_INITDB_ROOT_USERNAME: admin
      MONGO_INITDB_ROOT_PASSWORD: password
    healthcheck:
      test: echo 'db.runCommand("ping").ok' | mongosh localhost:27017
      interval: 10s
      timeout: 5s
      retries: 5

  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: bankmanager-api
    ports:
      - "3000:3000"
    depends_on:
      mongodb:
        condition: service_healthy
    environment:
      MONGODB_URI: mongodb://admin:password@mongodb:27017/bankmanager?authSource=admin
      PORT: 3000
      NODE_ENV: production
      JWT_SECRET: ${JWT_SECRET}
    volumes:
      - ./backend:/app
      - /app/node_modules
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    container_name: bankmanager-web
    ports:
      - "80:80"
    depends_on:
      - backend
    environment:
      REACT_APP_API_URL: http://localhost:3000/api
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost"]
      interval: 30s
      timeout: 10s
      retries: 3

  nginx:
    image: nginx:alpine
    container_name: bankmanager-proxy
    ports:
      - "8080:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
    depends_on:
      - backend
      - frontend
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost"]
      interval: 30s
      timeout: 10s
      retries: 3

volumes:
  mongo_data:

networks:
  default:
    name: bankmanager-network
```

### Deploy with Docker Compose
```bash
# Build all services
docker-compose build

# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop all services
docker-compose down

# Clean up (remove volumes)
docker-compose down -v
```

---

## 🌐 Production Deployment (AWS)

### Architecture
```
┌─────────────┐
│   CloudFront│  (CDN)
└──────┬──────┘
       │
┌──────▼──────────┐
│   ALB (80/443)  │  (Load Balancer)
└──────┬──────────┘
       │
┌──────┴──────────────────────────┐
│                                  │
│  ECS Cluster (Backend)          │
│  - Task Definition              │
│  - Auto Scaling Group           │
│  - Docker Container             │
│                                  │
└──────┬──────────────────────────┘
       │
┌──────▼──────────┐
│ RDS (MongoDB)   │  (Managed Database)
└─────────────────┘
```

### AWS Resources to Create

#### 1. VPC & Networking
```bash
# Create VPC
aws ec2 create-vpc --cidr-block 10.0.0.0/16

# Create Subnets
aws ec2 create-subnet --vpc-id <vpc-id> --cidr-block 10.0.1.0/24 --availability-zone us-east-1a
aws ec2 create-subnet --vpc-id <vpc-id> --cidr-block 10.0.2.0/24 --availability-zone us-east-1b

# Create Internet Gateway
aws ec2 create-internet-gateway
aws ec2 attach-internet-gateway --internet-gateway-id <igw-id> --vpc-id <vpc-id>

# Create Route Table
aws ec2 create-route-table --vpc-id <vpc-id>
aws ec2 create-route --route-table-id <rt-id> --destination-cidr-block 0.0.0.0/0 --gateway-id <igw-id>
```

#### 2. ECR Repository
```bash
# Create ECR repository for backend
aws ecr create-repository --repository-name bankmanager-backend

# Create ECR repository for frontend
aws ecr create-repository --repository-name bankmanager-frontend

# Push Docker images
docker tag bankmanager-backend:latest <account-id>.dkr.ecr.us-east-1.amazonaws.com/bankmanager-backend:latest
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin <account-id>.dkr.ecr.us-east-1.amazonaws.com
docker push <account-id>.dkr.ecr.us-east-1.amazonaws.com/bankmanager-backend:latest
```

#### 3. RDS (MongoDB Atlas or DocumentDB)
```bash
# Create RDS cluster (using DocumentDB for MongoDB compatibility)
aws docdb create-db-cluster \
  --db-cluster-identifier bankmanager-db \
  --engine docdb \
  --master-username admin \
  --master-password <password> \
  --vpc-security-group-ids <sg-id> \
  --db-subnet-group-name <subnet-group>
```

#### 4. ECS Cluster & Services
```bash
# Create ECS Cluster
aws ecs create-cluster --cluster-name bankmanager

# Register Task Definition
aws ecs register-task-definition --cli-input-json file://task-definition.json

# Create Service
aws ecs create-service \
  --cluster bankmanager \
  --service-name bankmanager-backend \
  --task-definition bankmanager-backend:1 \
  --desired-count 2 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[<subnet-id>],securityGroups=[<sg-id>]}"
```

#### 5. ALB (Application Load Balancer)
```bash
# Create Load Balancer
aws elbv2 create-load-balancer \
  --name bankmanager-alb \
  --subnets <subnet-id-1> <subnet-id-2> \
  --security-groups <sg-id>

# Create Target Group
aws elbv2 create-target-group \
  --name bankmanager-backend \
  --protocol HTTP \
  --port 3000 \
  --vpc-id <vpc-id>

# Create Listener
aws elbv2 create-listener \
  --load-balancer-arn <alb-arn> \
  --protocol HTTP \
  --port 80 \
  --default-actions Type=forward,TargetGroupArn=<tg-arn>
```

#### 6. Auto Scaling
```bash
# Create Auto Scaling Group
aws autoscaling create-auto-scaling-group \
  --auto-scaling-group-name bankmanager-asg \
  --launch-configuration bankmanager-lc \
  --min-size 2 \
  --max-size 10 \
  --desired-capacity 3 \
  --availability-zones us-east-1a us-east-1b \
  --load-balancer-names bankmanager-alb

# Create Scaling Policy
aws autoscaling put-scaling-policy \
  --auto-scaling-group-name bankmanager-asg \
  --policy-name scale-up \
  --policy-type TargetTrackingScaling \
  --target-tracking-configuration file://scaling-policy.json
```

---

## 🔐 Security Configuration

### Environment Variables (.env)
```env
# Database
MONGODB_URI=mongodb+srv://user:password@cluster.mongodb.net/bankmanager
MONGODB_OPTIONS={"retryWrites":true,"w":"majority"}

# Server
NODE_ENV=production
PORT=3000

# Authentication
JWT_SECRET=your-64-character-random-secret-key-here
JWT_EXPIRE=24h

# API Security
CORS_ORIGIN=https://yourdomain.com
RATE_LIMIT_WINDOW=15m
RATE_LIMIT_MAX_REQUESTS=100

# AWS (if using)
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key

# Monitoring
SENTRY_DSN=https://your-sentry-dsn
LOG_LEVEL=info

# Email Notifications
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
```

### SSL/TLS Configuration
```bash
# Generate self-signed certificate for development
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365

# For production, use Let's Encrypt via Certbot
certbot certonly --standalone -d yourdomain.com
```

### Nginx Configuration (nginx.conf)
```nginx
user nginx;
worker_processes auto;

events {
    worker_connections 1024;
}

http {
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

    # Compression
    gzip on;
    gzip_types text/plain text/css text/javascript application/json;
    gzip_min_length 1024;

    # Rate limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=general:10m rate=50r/s;

    # Upstream services
    upstream backend {
        least_conn;
        server backend:3000 weight=5;
        server backend-2:3000 weight=5;
        keepalive 32;
    }

    upstream frontend {
        server frontend:80;
    }

    # HTTP to HTTPS redirect
    server {
        listen 80;
        server_name yourdomain.com;
        return 301 https://$server_name$request_uri;
    }

    # HTTPS server
    server {
        listen 443 ssl http2;
        server_name yourdomain.com;

        ssl_certificate /etc/nginx/ssl/cert.pem;
        ssl_certificate_key /etc/nginx/ssl/key.pem;
        ssl_protocols TLSv1.2 TLSv1.3;
        ssl_ciphers HIGH:!aNULL:!MD5;

        # API routes
        location /api/ {
            limit_req zone=api burst=20 nodelay;
            proxy_pass http://backend;
            proxy_http_version 1.1;
            proxy_set_header Connection "";
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        # Frontend
        location / {
            limit_req zone=general burst=50 nodelay;
            proxy_pass http://frontend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }
    }
}
```

---

## 📊 Monitoring & Logging

### Application Monitoring (Node.js)

#### PM2 Configuration (ecosystem.config.js)
```javascript
module.exports = {
  apps: [
    {
      name: 'bankmanager-backend',
      script: './src/index.js',
      instances: 'max',
      exec_mode: 'cluster',
      env: {
        NODE_ENV: 'production'
      },
      error_file: './logs/error.log',
      out_file: './logs/out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      watch: false,
      ignore_watch: ['node_modules', 'logs'],
      max_memory_restart: '1G',
      restart_delay: 4000
    }
  ],
  deploy: {
    production: {
      user: 'ubuntu',
      host: 'your-server-ip',
      key: '~/.ssh/id_rsa',
      ref: 'origin/main',
      repo: 'git@github.com:your-repo.git',
      path: '/var/www/bankmanager',
      'post-deploy': 'npm install && pm2 reload ecosystem.config.js --env production'
    }
  }
};
```

### Logging with Winston
```javascript
const winston = require('winston');

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' }),
    new winston.transports.Console({
      format: winston.format.simple()
    })
  ]
});

module.exports = logger;
```

### Error Tracking (Sentry)
```javascript
const Sentry = require("@sentry/node");

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
  tracesSampleRate: 1.0
});

// Use in Express
app.use(Sentry.Handlers.requestHandler());
app.use(Sentry.Handlers.errorHandler());
```

---

## ✅ Testing & CI/CD

### GitHub Actions Workflow (.github/workflows/deploy.yml)
```yaml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: |
          cd backend && npm ci
          cd ../frontend && npm ci
      
      - name: Run tests
        run: |
          cd backend && npm test
          cd ../frontend && npm test

  build:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Build Docker images
        run: |
          docker build -t bankmanager-backend:${{ github.sha }} ./backend
          docker build -t bankmanager-frontend:${{ github.sha }} ./frontend
      
      - name: Push to ECR
        env:
          AWS_ACCESS_KEY_ID: ${{ secrets.AWS_ACCESS_KEY_ID }}
          AWS_SECRET_ACCESS_KEY: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          AWS_DEFAULT_REGION: us-east-1
        run: |
          aws ecr get-login-password | docker login --username AWS --password-stdin ${{ secrets.ECR_REGISTRY }}
          docker push ${{ secrets.ECR_REGISTRY }}/bankmanager-backend:${{ github.sha }}
          docker push ${{ secrets.ECR_REGISTRY }}/bankmanager-frontend:${{ github.sha }}

  deploy:
    needs: build
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to ECS
        env:
          AWS_ACCESS_KEY_ID: ${{ secrets.AWS_ACCESS_KEY_ID }}
          AWS_SECRET_ACCESS_KEY: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          AWS_DEFAULT_REGION: us-east-1
        run: |
          aws ecs update-service \
            --cluster bankmanager \
            --service bankmanager-backend \
            --force-new-deployment
```

---

## 🧪 Testing

### Unit Tests (Jest)
```bash
# Backend tests
cd backend && npm test

# Frontend tests
cd frontend && npm test
```

### Load Testing (Apache JMeter)
```bash
# Create test plan for transaction parsing endpoint
jmeter -n -t load-test.jmx -l results.jtl -j load-test.log

# Analyze results
jmeter -g results.jtl
```

---

## 📈 Performance Optimization

### Database Indexing
```javascript
// Ensure these indexes exist for fast queries
db.transactions.createIndex({ userId: 1, timestamp: -1 })
db.transactions.createIndex({ userId: 1, category: 1 })
db.transactions.createIndex({ userId: 1, hasCashback: 1 })
db.transactions.createIndex({ merchant: 1 })
```

### Caching Strategy
```javascript
const redis = require('redis');
const client = redis.createClient({
  host: process.env.REDIS_HOST || 'localhost',
  port: process.env.REDIS_PORT || 6379
});

// Cache category metrics for 1 hour
app.get('/api/metrics/:userId', (req, res) => {
  const cacheKey = `metrics:${req.params.userId}`;
  
  client.get(cacheKey, (err, data) => {
    if (data) {
      return res.json(JSON.parse(data));
    }
    
    // Fetch from DB and cache
    const metrics = calculateMetrics();
    client.setex(cacheKey, 3600, JSON.stringify(metrics));
    res.json(metrics);
  });
});
```

---

## 🛠️ Troubleshooting

### Common Issues

#### 1. MongoDB Connection Failed
```bash
# Check if MongoDB is running
sudo systemctl status mongod

# Verify connection string
mongodb+srv://user:password@cluster.mongodb.net/dbname?retryWrites=true&w=majority

# Check firewall rules
sudo ufw allow 27017
```

#### 2. API Rate Limiting Issues
```bash
# Increase rate limit in nginx.conf or environment variable
RATE_LIMIT_MAX_REQUESTS=1000
```

#### 3. Docker Container Exit Code 1
```bash
# Check logs
docker logs <container-id>

# Rebuild without cache
docker-compose build --no-cache
```

---

## 📞 Support & Maintenance

### Health Checks
```bash
# Backend health
curl http://localhost:3000/health

# Database health
curl http://localhost:3000/api/health/db

# API availability
curl http://localhost:3000/api/metrics
```

### Backup & Recovery
```bash
# Backup MongoDB
mongodump --uri="mongodb://localhost:27017/bankmanager" --out=./backup

# Restore MongoDB
mongorestore --uri="mongodb://localhost:27017/bankmanager" ./backup
```

---

## 📝 License

MIT License - See LICENSE.md for details
