/**
 * Database Models and Schema Definitions
 * Framework: MongoDB + Mongoose
 * Purpose: Define data structure and persistence layer
 */

const mongoose = require('mongoose');

// ==================== TRANSACTION SCHEMA ====================
/**
 * Stores individual transaction records
 * Optimized for:
 * - Fast queries by userId + date range
 * - Category-based aggregations
 * - Reward/cashback tracking
 */
const transactionSchema = new mongoose.Schema({
  // Core transaction data
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  description: {
    type: String,
    required: true,
    trim: true
  },
  amount: {
    type: Number,
    required: true
    // Negative = outgoing, Positive = incoming
  },
  timestamp: {
    type: Date,
    required: true,
    index: true,
    default: Date.now
  },
  
  // Categorization data
  category: {
    type: String,
    enum: [
      'Food & Dining',
      'Travel',
      'Salary',
      'Shopping',
      'Utilities',
      'Healthcare',
      'Entertainment',
      'Miscellaneous'
    ],
    required: true,
    index: true
  },
  customCategory: {
    type: String,
    default: null
  },
  autoAssigned: {
    type: Boolean,
    default: true
  },
  confidence: {
    type: Number,
    min: 0,
    max: 1,
    default: 1.0
  },
  
  // Merchant information
  merchant: {
    type: String,
    trim: true,
    index: true
  },
  merchantKeywordsMatched: [{
    type: String
  }],
  
  // Cashback and rewards tracking
  hasCashback: {
    type: Boolean,
    default: false,
    index: true
  },
  savingsAmount: {
    type: Number,
    default: 0
  },
  estimatedCashbackPercentage: {
    type: Number,
    default: 0
  },
  rewardPartner: {
    type: String,
    default: null
  },
  savingsClaimed: {
    type: Boolean,
    default: false
  },
  claimedDate: {
    type: Date,
    default: null
  },
  
  // Transaction metadata
  transactionType: {
    type: String,
    enum: ['outgoing', 'incoming', 'transfer'],
    required: true
  },
  status: {
    type: String,
    enum: ['completed', 'pending', 'failed', 'cancelled'],
    default: 'completed'
  },
  bankAccount: {
    type: String,
    default: null
  },
  
  // Audit trail
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  updatedBy: {
    type: String,
    enum: ['system', 'user', 'admin'],
    default: 'system'
  }
}, {
  timestamps: true,
  indexes: [
    { userId: 1, timestamp: -1 },        // Fast query by user + time
    { userId: 1, category: 1 },          // Category aggregations
    { userId: 1, hasCashback: 1 },       // Rewards tracking
    { merchant: 1 },                      // Merchant lookup
    { timestamp: -1 }                     // Recent transactions
  ]
});

// ==================== USER SCHEMA ====================
/**
 * Stores user profile and preferences
 */
const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    index: true
  },
  phone: {
    type: String,
    default: null
  },
  
  // Notification preferences
  preferences: {
    notifications: {
      highSpending: Boolean,
      cashbackAlerts: Boolean,
      weeklyReport: Boolean,
      monthlyReport: Boolean
    },
    thresholds: {
      highSpendingAlert: {
        type: Number,
        default: 5000
      },
      dailyBudget: {
        type: Number,
        default: 2000
      }
    }
  },
  
  // Categorization overrides
  categoryRules: [{
    keyword: String,
    category: String,
    priority: Number
  }],
  
  // Statistics
  totalSpending: {
    type: Number,
    default: 0
  },
  totalSavings: {
    type: Number,
    default: 0
  },
  transactionCount: {
    type: Number,
    default: 0
  },
  
  // Account status
  status: {
    type: String,
    enum: ['active', 'inactive', 'suspended'],
    default: 'active'
  },
  
  // Metadata
  createdAt: {
    type: Date,
    default: Date.now
  },
  lastLogin: {
    type: Date,
    default: null
  }
}, {
  timestamps: true
});

// ==================== CATEGORY CONFIGURATION SCHEMA ====================
/**
 * Stores merchant keywords and category mappings
 * Allows dynamic updates without code changes
 */
const categoryConfigSchema = new mongoose.Schema({
  category: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  keywords: [{
    keyword: {
      type: String,
      lowercase: true,
      trim: true
    },
    priority: {
      type: Number,
      default: 1
    },
    active: {
      type: Boolean,
      default: true
    }
  }],
  icon: String,
  color: String,
  description: String,
  builtIn: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// ==================== REWARD PARTNER SCHEMA ====================
/**
 * Stores reward partner information for cashback detection
 */
const rewardPartnerSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
    index: true,
    lowercase: true
  },
  keywords: [{
    keyword: {
      type: String,
      lowercase: true
    },
    weight: {
      type: Number,
      default: 1
    }
  }],
  cashbackPercentage: {
    type: Number,
    default: 0,
    min: 0,
    max: 100
  },
  maxCashback: {
    type: Number,
    default: null
  },
  maxCashbackPerTransaction: {
    type: Number,
    default: null
  },
  validTill: {
    type: Date,
    default: null
  },
  active: {
    type: Boolean,
    default: true,
    index: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// ==================== METRICS CACHE SCHEMA ====================
/**
 * Stores pre-calculated metrics for fast retrieval
 * Updated daily via background job
 */
const metricsCacheSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true,
    index: true
  },
  period: {
    type: String,
    enum: ['daily', 'weekly', 'monthly', 'yearly'],
    required: true
  },
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    required: true
  },
  
  // Spending metrics by category
  categoryMetrics: {
    type: Map,
    of: {
      total: Number,
      count: Number,
      average: Number
    }
  },
  
  // Overall metrics
  totalSpending: Number,
  totalIncome: Number,
  netCashFlow: Number,
  transactionCount: Number,
  
  // Top insights
  topCategory: String,
  topMerchant: String,
  topCategoryAmount: Number,
  topMerchantAmount: Number,
  
  // Savings metrics
  totalSavings: Number,
  savingsOpportunityCount: Number,
  
  // Status
  status: {
    type: String,
    enum: ['valid', 'stale', 'outdated'],
    default: 'valid'
  },
  
  // Metadata
  cachedAt: {
    type: Date,
    default: Date.now
  },
  expiresAt: {
    type: Date,
    index: true
  }
}, {
  timestamps: true
});

// ==================== ANALYTICS REPORT SCHEMA ====================
/**
 * Stores historical reports for trend analysis
 */
const analyticsReportSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  reportType: {
    type: String,
    enum: ['daily', 'weekly', 'monthly', 'yearly'],
    required: true
  },
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    required: true
  },
  
  // Report data
  data: {
    totalSpending: Number,
    totalIncome: Number,
    categories: Map,
    topMerchants: Array,
    insights: Array,
    trends: Array
  },
  
  // Comparisons
  previousPeriodComparison: {
    spendingChange: Number,
    incomeChange: Number,
    categoryChanges: Map
  },
  
  // Metadata
  status: {
    type: String,
    enum: ['generated', 'sent', 'viewed'],
    default: 'generated'
  },
  sentAt: Date,
  viewedAt: Date,
  
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// ==================== BUDGET SCHEMA ====================
/**
 * Stores user-defined budgets for category spending
 */
const budgetSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  category: {
    type: String,
    required: true
  },
  limitAmount: {
    type: Number,
    required: true
  },
  period: {
    type: String,
    enum: ['daily', 'weekly', 'monthly', 'yearly'],
    default: 'monthly'
  },
  currentSpending: {
    type: Number,
    default: 0
  },
  percentageUsed: {
    type: Number,
    default: 0,
    min: 0,
    max: 100
  },
  
  // Status
  active: {
    type: Boolean,
    default: true
  },
  alertThreshold: {
    type: Number,
    default: 80  // Alert when 80% spent
  },
  
  // Dates
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    default: null
  },
  
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// ==================== SCHEMA EXPORTS ====================
module.exports = {
  Transaction: mongoose.model('Transaction', transactionSchema),
  User: mongoose.model('User', userSchema),
  CategoryConfig: mongoose.model('CategoryConfig', categoryConfigSchema),
  RewardPartner: mongoose.model('RewardPartner', rewardPartnerSchema),
  MetricsCache: mongoose.model('MetricsCache', metricsCacheSchema),
  AnalyticsReport: mongoose.model('AnalyticsReport', analyticsReportSchema),
  Budget: mongoose.model('Budget', budgetSchema)
};

/**
 * DATABASE SETUP:
 * 
 * 1. Create MongoDB database
 * 2. Connect using Mongoose in main app:
 *    
 *    const mongoose = require('mongoose');
 *    mongoose.connect('mongodb://localhost:27017/bankmanager', {
 *      useNewUrlParser: true,
 *      useUnifiedTopology: true
 *    });
 * 
 * 3. Seed initial categories
 */

/**
 * SEEDING INITIAL DATA:
 * 
 * const { CategoryConfig, RewardPartner } = require('./models');
 * 
 * async function seedData() {
 *   // Seed categories
 *   await CategoryConfig.insertMany([
 *     {
 *       category: 'Food & Dining',
 *       keywords: ['zomato', 'swiggy', 'dominos'],
 *       color: '#C84B31'
 *     },
 *     // ... more categories
 *   ]);
 *   
 *   // Seed reward partners
 *   await RewardPartner.insertMany([
 *     {
 *       name: 'zomato',
 *       cashbackPercentage: 2,
 *       active: true
 *     },
 *     // ... more partners
 *   ]);
 * }
 */
