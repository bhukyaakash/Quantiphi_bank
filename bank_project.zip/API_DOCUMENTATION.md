# Bank Transaction Manager - API Documentation

## 📚 API Reference

**Base URL**: `https://api.yourdomain.com/api`
**Version**: 1.0.0
**Authentication**: JWT Bearer Token

---

## 🔐 Authentication

### Authentication Header
```
Authorization: Bearer <jwt_token>
```

### Get JWT Token
```
POST /auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123"
}

Response:
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "expiresIn": "24h",
  "user": {
    "id": "user123",
    "name": "John Doe",
    "email": "user@example.com"
  }
}
```

---

## 📌 Transaction Endpoints

### 1. Parse Single Transaction
Parse and auto-categorize a single raw transaction text.

```
POST /transactions/parse
Authorization: Bearer <token>
Content-Type: application/json

Request Body:
{
  "rawText": "Paid Rs. 850 to Zomato"
}

Response (200):
{
  "success": true,
  "transaction": {
    "description": "Paid Rs. 850 to Zomato",
    "amount": -850,
    "category": "Food & Dining",
    "timestamp": "2024-01-15T10:30:00Z",
    "hasCashback": true,
    "savingsAmount": 125,
    "rewardPartner": "zomato",
    "estimatedCashbackPercentage": "2.50"
  }
}
```

**Response Codes**:
- `200` - Successfully parsed and categorized
- `400` - Invalid request body
- `401` - Unauthorized (missing/invalid token)
- `500` - Server error

---

### 2. Batch Process Transactions
Process multiple transaction texts in a single request.

```
POST /transactions/batch
Authorization: Bearer <token>
Content-Type: application/json

Request Body:
{
  "transactions": [
    "Paid Rs. 850 to Zomato",
    "Paid Rs. 1200 to Uber Cab",
    "Received Rs. 45000 Salary from TechCorp",
    "Paid Rs. 5499 to Amazon Shopping"
  ]
}

Response (200):
{
  "success": true,
  "processed": 4,
  "transactions": [
    {
      "id": 1,
      "description": "Paid Rs. 850 to Zomato",
      "amount": -850,
      "category": "Food & Dining",
      "timestamp": "2024-01-15T10:30:00Z",
      "hasCashback": true,
      "savingsAmount": 125
    },
    {
      "id": 2,
      "description": "Paid Rs. 1200 to Uber Cab",
      "amount": -1200,
      "category": "Travel",
      "timestamp": "2024-01-15T10:30:00Z",
      "hasCashback": true,
      "savingsAmount": 98
    },
    // ... more transactions
  ]
}
```

---

### 3. Get User Transactions
Retrieve paginated list of user's transactions.

```
GET /transactions?page=1&limit=20&category=Food%20%26%20Dining&startDate=2024-01-01&endDate=2024-01-31
Authorization: Bearer <token>

Query Parameters:
- page: Page number (default: 1)
- limit: Items per page (default: 20, max: 100)
- category: Filter by category (optional)
- startDate: Filter by start date (ISO format, optional)
- endDate: Filter by end date (ISO format, optional)
- sortBy: Sort field (timestamp, amount, category, default: timestamp)
- sortOrder: asc or desc (default: desc)

Response (200):
{
  "success": true,
  "data": [
    {
      "id": "60f7b3b3b3b3b3b3b3b3b3b3",
      "userId": "user123",
      "description": "Paid Rs. 850 to Zomato",
      "amount": -850,
      "category": "Food & Dining",
      "customCategory": null,
      "timestamp": "2024-01-15T10:30:00Z",
      "merchant": "Zomato",
      "hasCashback": true,
      "savingsAmount": 125,
      "status": "completed",
      "createdAt": "2024-01-15T10:30:00Z",
      "updatedAt": "2024-01-15T10:30:00Z"
    },
    // ... more transactions
  ],
  "pagination": {
    "currentPage": 1,
    "totalPages": 5,
    "totalItems": 95,
    "itemsPerPage": 20,
    "hasMore": true
  }
}
```

---

### 4. Get Single Transaction
Retrieve details of a specific transaction.

```
GET /transactions/:id
Authorization: Bearer <token>

Response (200):
{
  "success": true,
  "transaction": {
    "id": "60f7b3b3b3b3b3b3b3b3b3b3",
    "userId": "user123",
    "description": "Paid Rs. 850 to Zomato",
    "amount": -850,
    "category": "Food & Dining",
    "customCategory": null,
    "timestamp": "2024-01-15T10:30:00Z",
    "merchant": "Zomato",
    "hasCashback": true,
    "savingsAmount": 125,
    "estimatedCashbackPercentage": 2.5,
    "transactionType": "outgoing",
    "status": "completed",
    "createdAt": "2024-01-15T10:30:00Z",
    "updatedAt": "2024-01-15T10:30:00Z"
  }
}
```

---

### 5. Update Transaction Category
Manually override or change transaction category.

```
PATCH /transactions/:id/category
Authorization: Bearer <token>
Content-Type: application/json

Request Body:
{
  "category": "Shopping",
  "customCategory": "Shopping"
}

Response (200):
{
  "success": true,
  "transaction": {
    "id": "60f7b3b3b3b3b3b3b3b3b3b3",
    "description": "Paid Rs. 850 to Zomato",
    "amount": -850,
    "category": "Food & Dining",
    "customCategory": "Shopping",
    "timestamp": "2024-01-15T10:30:00Z"
  }
}
```

---

### 6. Bulk Update Categories
Update categories for multiple transactions.

```
PATCH /transactions/bulk/category
Authorization: Bearer <token>
Content-Type: application/json

Request Body:
{
  "transactionIds": [
    "60f7b3b3b3b3b3b3b3b3b3b3",
    "60f7b3b3b3b3b3b3b3b3b3b4",
    "60f7b3b3b3b3b3b3b3b3b3b5"
  ],
  "category": "Shopping"
}

Response (200):
{
  "success": true,
  "updated": 3,
  "transactions": [...]
}
```

---

### 7. Delete Transaction
Delete a transaction record.

```
DELETE /transactions/:id
Authorization: Bearer <token>

Response (200):
{
  "success": true,
  "message": "Transaction deleted successfully",
  "id": "60f7b3b3b3b3b3b3b3b3b3b3"
}
```

---

## 📊 Metrics & Analytics Endpoints

### 1. Calculate Metrics
Calculate spending metrics from a set of transactions.

```
POST /metrics/calculate
Authorization: Bearer <token>
Content-Type: application/json

Request Body:
{
  "transactions": [
    {
      "id": 1,
      "description": "Paid Rs. 850 to Zomato",
      "amount": -850,
      "category": "Food & Dining",
      "customCategory": null,
      "hasCashback": true,
      "savingsAmount": 125
    },
    // ... more transactions
  ]
}

Response (200):
{
  "success": true,
  "metrics": {
    "Food & Dining": {
      "total": 1170,
      "count": 2,
      "outgoingCount": 2,
      "incomingCount": 0,
      "incomingTotal": 0,
      "transactions": [...]
    },
    "Travel": {
      "total": 1200,
      "count": 1,
      "outgoingCount": 1,
      "incomingCount": 0,
      "incomingTotal": 0,
      "transactions": [...]
    },
    "Salary": {
      "total": 0,
      "count": 1,
      "outgoingCount": 0,
      "incomingCount": 1,
      "incomingTotal": 45000,
      "transactions": [...]
    }
  },
  "summary": {
    "totalSpending": 8269,
    "totalIncome": 45000,
    "netCashFlow": 36731,
    "topCategory": "Food & Dining",
    "transactionCount": 7,
    "averageTransaction": 1181
  }
}
```

---

### 2. Get User Metrics
Get pre-calculated metrics for a user (fast cached response).

```
GET /metrics/:userId?period=monthly&startDate=2024-01-01&endDate=2024-01-31
Authorization: Bearer <token>

Query Parameters:
- period: daily, weekly, monthly, yearly (default: monthly)
- startDate: ISO format date (optional)
- endDate: ISO format date (optional)

Response (200):
{
  "success": true,
  "metrics": {
    "Food & Dining": { "total": 5400, "count": 8 },
    "Travel": { "total": 3200, "count": 4 },
    "Shopping": { "total": 12000, "count": 6 },
    "Salary": { "total": 95000, "count": 2 },
    "Miscellaneous": { "total": 1200, "count": 5 }
  },
  "summary": {
    "totalSpending": 21800,
    "totalIncome": 95000,
    "netCashFlow": 73200,
    "topCategory": "Shopping",
    "topCategoryAmount": 12000,
    "transactionCount": 25,
    "periodStart": "2024-01-01",
    "periodEnd": "2024-01-31",
    "cachedAt": "2024-01-15T10:30:00Z"
  }
}
```

---

### 3. Generate Insights
Generate AI-powered insights and recommendations.

```
POST /analytics/insights
Authorization: Bearer <token>
Content-Type: application/json

Request Body:
{
  "transactions": [...]
}

Response (200):
{
  "success": true,
  "insights": [
    {
      "type": "high_spending",
      "category": "Food & Dining",
      "amount": 5400,
      "message": "High spending detected in Food & Dining: Rs. 5400"
    },
    {
      "type": "savings_opportunity",
      "amount": 2450,
      "transactionCount": 15,
      "message": "Potential savings of Rs. 2450 from cashback"
    },
    {
      "type": "recurring_merchant",
      "merchant": "Zomato",
      "count": 8,
      "message": "Frequent merchant: Zomato (8 transactions)"
    }
  ],
  "insightCount": 3
}
```

---

### 4. Get Category Summary
Get spending summary grouped by category.

```
GET /analytics/category-summary?startDate=2024-01-01&endDate=2024-01-31
Authorization: Bearer <token>

Response (200):
{
  "success": true,
  "summary": {
    "Food & Dining": {
      "total": 5400,
      "count": 8,
      "average": 675,
      "percentage": 24.8,
      "merchants": ["Zomato", "Swiggy", "KFC"]
    },
    "Travel": {
      "total": 3200,
      "count": 4,
      "average": 800,
      "percentage": 14.7,
      "merchants": ["Uber", "Ola"]
    },
    // ... more categories
  },
  "total": 21800,
  "period": {
    "start": "2024-01-01",
    "end": "2024-01-31"
  }
}
```

---

### 5. Get Merchant Summary
Get merchant-wise spending breakdown.

```
GET /analytics/merchant-summary?limit=10&sortBy=amount
Authorization: Bearer <token>

Query Parameters:
- limit: Number of top merchants to return (default: 10)
- sortBy: amount or count (default: amount)

Response (200):
{
  "success": true,
  "merchants": [
    {
      "name": "Zomato",
      "category": "Food & Dining",
      "total": 3400,
      "count": 8,
      "average": 425,
      "lastTransaction": "2024-01-15T10:30:00Z",
      "frequency": "weekly"
    },
    {
      "name": "Amazon",
      "category": "Shopping",
      "total": 12000,
      "count": 6,
      "average": 2000,
      "lastTransaction": "2024-01-10T15:45:00Z",
      "frequency": "monthly"
    },
    // ... more merchants
  ],
  "totalUniqueMerchants": 25
}
```

---

## 🏷️ Merchant & Category Endpoints

### 1. Get All Categories
Retrieve all available transaction categories.

```
GET /merchants
Authorization: Bearer <token>

Response (200):
{
  "success": true,
  "merchants": {
    "Food & Dining": [
      "zomato", "swiggy", "dominos", "kfc", "mcdonalds",
      "pizza hut", "subway", "cafe", "restaurant"
    ],
    "Travel": [
      "uber", "ola", "redbus", "goibibo", "make my trip",
      "irctc", "airline", "flight", "taxi"
    ],
    "Salary": [
      "salary", "payroll", "wages", "stipend", "income"
    ],
    "Shopping": [
      "amazon", "flipkart", "myntra", "ajio", "ebay"
    ]
  },
  "totalKeywords": 156
}
```

---

### 2. Get Category Keywords
Get all merchants/keywords for a specific category.

```
GET /merchants/:category
Authorization: Bearer <token>

Response (200):
{
  "success": true,
  "category": "Food & Dining",
  "merchants": [
    "zomato", "swiggy", "dominos", "kfc", "mcdonalds",
    "pizza hut", "subway", "cafe", "restaurant", "food"
  ]
}
```

---

### 3. Add New Merchant Keyword
Add a new merchant keyword for better categorization.

```
POST /merchants/add
Authorization: Bearer <token>
Content-Type: application/json

Request Body:
{
  "category": "Food & Dining",
  "merchant": "WickedGoodBurgers"
}

Response (200):
{
  "success": true,
  "message": "Added WickedGoodBurgers to Food & Dining",
  "category": "Food & Dining",
  "merchants": [
    // ... updated merchant list
  ]
}
```

---

### 4. Get Reward Partners
Get list of merchants that offer cashback/rewards.

```
GET /reward-partners
Authorization: Bearer <token>

Response (200):
{
  "success": true,
  "partners": [
    {
      "name": "Zomato",
      "cashbackPercentage": 2.5,
      "maxCashback": 500,
      "validTill": "2024-12-31"
    },
    {
      "name": "Amazon",
      "cashbackPercentage": 1.5,
      "maxCashback": 1000,
      "validTill": "2024-12-31"
    },
    // ... more partners
  ],
  "totalPartners": 8
}
```

---

## 💰 Budget & Alert Endpoints

### 1. Create Budget
Create a spending budget for a category.

```
POST /budgets
Authorization: Bearer <token>
Content-Type: application/json

Request Body:
{
  "category": "Food & Dining",
  "limitAmount": 3000,
  "period": "monthly",
  "startDate": "2024-01-01",
  "alertThreshold": 80
}

Response (201):
{
  "success": true,
  "budget": {
    "id": "budget123",
    "userId": "user123",
    "category": "Food & Dining",
    "limitAmount": 3000,
    "currentSpending": 1250,
    "percentageUsed": 41.7,
    "period": "monthly",
    "startDate": "2024-01-01",
    "active": true,
    "alertThreshold": 80,
    "createdAt": "2024-01-15T10:30:00Z"
  }
}
```

---

### 2. Get User Budgets
Retrieve all budgets for a user.

```
GET /budgets
Authorization: Bearer <token>

Response (200):
{
  "success": true,
  "budgets": [
    {
      "id": "budget123",
      "category": "Food & Dining",
      "limitAmount": 3000,
      "currentSpending": 1250,
      "percentageUsed": 41.7,
      "period": "monthly",
      "active": true,
      "alertThreshold": 80
    },
    {
      "id": "budget456",
      "category": "Travel",
      "limitAmount": 2000,
      "currentSpending": 1800,
      "percentageUsed": 90,
      "period": "monthly",
      "active": true,
      "alertThreshold": 80
    }
  ],
  "totalBudgets": 2
}
```

---

### 3. Update Budget
Modify an existing budget.

```
PATCH /budgets/:id
Authorization: Bearer <token>
Content-Type: application/json

Request Body:
{
  "limitAmount": 4000,
  "alertThreshold": 75
}

Response (200):
{
  "success": true,
  "budget": {
    "id": "budget123",
    "category": "Food & Dining",
    "limitAmount": 4000,
    "alertThreshold": 75
  }
}
```

---

### 4. Delete Budget
Remove a budget.

```
DELETE /budgets/:id
Authorization: Bearer <token>

Response (200):
{
  "success": true,
  "message": "Budget deleted successfully"
}
```

---

## 📧 Report Endpoints

### 1. Generate Report
Generate a spending report for a date range.

```
POST /reports/generate
Authorization: Bearer <token>
Content-Type: application/json

Request Body:
{
  "reportType": "monthly",
  "startDate": "2024-01-01",
  "endDate": "2024-01-31",
  "includeInsights": true,
  "format": "json"
}

Response (200):
{
  "success": true,
  "report": {
    "id": "report123",
    "reportType": "monthly",
    "period": {
      "start": "2024-01-01",
      "end": "2024-01-31"
    },
    "data": {
      "totalSpending": 21800,
      "totalIncome": 95000,
      "netCashFlow": 73200,
      "categories": {
        "Food & Dining": { "total": 5400, "count": 8 },
        "Travel": { "total": 3200, "count": 4 },
        // ... more categories
      },
      "topMerchants": [
        { "name": "Zomato", "amount": 3400 },
        { "name": "Amazon", "amount": 12000 }
      ],
      "insights": [...]
    },
    "generatedAt": "2024-01-15T10:30:00Z"
  }
}
```

---

### 2. Export Report
Export report in different formats.

```
GET /reports/:id/export?format=pdf
Authorization: Bearer <token>

Query Parameters:
- format: json, csv, pdf, excel (default: json)

Response (200):
- PDF: application/pdf
- CSV: text/csv
- Excel: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
```

---

## ❌ Error Handling

### Standard Error Response
```
{
  "success": false,
  "error": {
    "code": "INVALID_REQUEST",
    "message": "Request validation failed",
    "details": [
      {
        "field": "rawText",
        "message": "rawText is required"
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### Error Codes
```
400 - BAD_REQUEST
  Invalid input parameters
  
401 - UNAUTHORIZED
  Missing or invalid authentication token
  
403 - FORBIDDEN
  Access denied to resource
  
404 - NOT_FOUND
  Resource not found
  
409 - CONFLICT
  Resource already exists
  
429 - RATE_LIMITED
  Too many requests
  
500 - INTERNAL_SERVER_ERROR
  Server error
```

---

## 🔄 Rate Limiting

Rate limits are applied per API key/user:

- **Standard Tier**: 100 requests/minute
- **Pro Tier**: 1000 requests/minute
- **Enterprise**: Custom limits

Rate limit headers:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 47
X-RateLimit-Reset: 1642252800
```

---

## 📦 Webhook Events

### Supported Events
```
transaction.created
transaction.categorized
transaction.updated
budget.exceeded
report.generated
cashback.earned
```

### Webhook Payload
```json
{
  "event": "transaction.categorized",
  "timestamp": "2024-01-15T10:30:00Z",
  "data": {
    "transactionId": "60f7b3b3b3b3b3b3b3b3b3b3",
    "category": "Food & Dining",
    "confidence": 0.95
  }
}
```

---

## 🧪 Testing

### cURL Examples

#### Parse Transaction
```bash
curl -X POST https://api.yourdomain.com/api/transactions/parse \
  -H "Authorization: Bearer your-token" \
  -H "Content-Type: application/json" \
  -d '{
    "rawText": "Paid Rs. 850 to Zomato"
  }'
```

#### Get Metrics
```bash
curl -X GET "https://api.yourdomain.com/api/metrics/user123?period=monthly" \
  -H "Authorization: Bearer your-token"
```

#### Get Transactions
```bash
curl -X GET "https://api.yourdomain.com/api/transactions?page=1&limit=20" \
  -H "Authorization: Bearer your-token"
```

---

## 📖 SDK Examples

### JavaScript/Node.js
```javascript
const axios = require('axios');

const client = axios.create({
  baseURL: 'https://api.yourdomain.com/api',
  headers: {
    Authorization: `Bearer ${token}`
  }
});

// Parse transaction
const result = await client.post('/transactions/parse', {
  rawText: 'Paid Rs. 850 to Zomato'
});

// Get metrics
const metrics = await client.get('/metrics/user123');

// Create budget
const budget = await client.post('/budgets', {
  category: 'Food & Dining',
  limitAmount: 3000,
  period: 'monthly'
});
```

### Python
```python
import requests

class BankManagerClient:
    def __init__(self, token):
        self.headers = {'Authorization': f'Bearer {token}'}
        self.base_url = 'https://api.yourdomain.com/api'
    
    def parse_transaction(self, raw_text):
        resp = requests.post(
            f'{self.base_url}/transactions/parse',
            json={'rawText': raw_text},
            headers=self.headers
        )
        return resp.json()
    
    def get_metrics(self, user_id):
        resp = requests.get(
            f'{self.base_url}/metrics/{user_id}',
            headers=self.headers
        )
        return resp.json()

# Usage
client = BankManagerClient(token='your-token')
result = client.parse_transaction('Paid Rs. 850 to Zomato')
```

---

## 📞 Support

For API support and issues:
- Documentation: https://docs.yourdomain.com
- Email: support@yourdomain.com
- Status Page: https://status.yourdomain.com
