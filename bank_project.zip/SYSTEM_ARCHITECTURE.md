# Bank Transaction UPI Summary & Categorization System
## Complete Architecture Documentation

---

## 📋 System Overview

A full-stack money manager application that:
- ✅ Parses unstructured transaction alerts
- ✅ Auto-categorizes transactions using keyword matching
- ✅ Visualizes spending habits with category analytics
- ✅ Detects cashback rewards and shows expected savings
- ✅ Provides interactive category management

---

## 🏗️ Architecture Layers

### Layer 1: Data Input & Parsing
**Component**: Transaction Parser
**Responsibility**: Convert raw transaction alerts to structured data

```
Raw Input: "Paid Rs. 850 to Zomato"
    ↓
Parser (Text → Object)
    ↓
Structured: {
  description: "Paid Rs. 850 to Zomato",
  amount: -850,
  timestamp: Date,
  merchantName: "Zomato",
  rawAmount: "850"
}
```

### Layer 2: Intelligence & Categorization
**Component**: Merchant Keyword Engine + Category Classifier
**Responsibility**: Auto-assign transaction categories

```
Keywords Database:
  Food & Dining: ['zomato', 'swiggy', 'dominos', 'kfc', ...]
  Travel: ['uber', 'ola', 'redbus', ...]
  Salary: ['salary', 'payroll', ...]
  Shopping: ['amazon', 'flipkart', ...]

Categorization Logic:
  Input: "Paid Rs. 850 to Zomato"
  Match: "zomato" ∈ Food & Dining keywords
  Output: Category = "Food & Dining"
```

### Layer 3: Rewards Detection & Calculation
**Component**: Cashback Detector + Savings Calculator
**Responsibility**: Identify reward opportunities and calculate projections

```
Rules:
  - Detect "cashback" keyword in description
  - Match transaction with reward partners
  - Reward Partners: ['amazon', 'flipkart', 'swiggy', 'zomato', 'uber']

Expected Savings Calculation:
  Base: Rs. 50-500 (random simulation, replace with actual API)
  Logic: IF (hasCashback AND isOutgoing) THEN showSavings()
```

### Layer 4: Metrics Aggregation
**Component**: Cumulative Reducer
**Responsibility**: Calculate category totals and spending patterns

```
Reducer Function:
  Input: [Transaction, Transaction, ...]
  Process:
    - Filter by category
    - Sum amounts (outgoing negative, incoming positive)
    - Isolate spending (amount < 0)
  Output: {
    "Food & Dining": { total: 1170, count: 2 },
    "Travel": { total: 1200, count: 1 },
    ...
  }
```

### Layer 5: Presentation & Interaction
**Component**: React Frontend with Charts
**Responsibility**: Display data and handle user interactions

---

## 💾 Data Structures

### Transaction Object
```javascript
{
  id: number,                      // Unique identifier
  description: string,             // Raw transaction text
  amount: number,                  // Positive (incoming) or negative (outgoing)
  timestamp: Date,                 // Transaction datetime
  category: string,                // Auto-assigned category
  customCategory: string | null,   // User override (if changed)
  hasCashback: boolean,            // Detected reward transaction
  savingsAmount: number,           // Projected cashback/rewards
}
```

### Category Metrics
```javascript
{
  "Food & Dining": {
    total: 1170,      // Sum of all outgoing amounts
    count: 2,         // Number of transactions
  },
  "Travel": {
    total: 1200,
    count: 1,
  },
  // ... more categories
}
```

### Merchant Keywords Map
```javascript
{
  "Food & Dining": [
    "zomato", "swiggy", "dominos", "kfc", 
    "mcdonalds", "pizza hut", "subway", 
    "cafe", "restaurant", "food"
  ],
  "Travel": [
    "uber", "ola", "redbus", "goibibo",
    "make my trip", "irctc", "airline",
    "flight", "taxi", "transit"
  ],
  // ... more categories
}
```

---

## 🔧 Backend Logic Implementation

### 1. Auto-Categorization Engine

```javascript
const categorizeTransaction = (description) => {
  const lowerDesc = description.toLowerCase();
  
  // Iterate through merchant keywords
  for (const [category, keywords] of Object.entries(merchantKeywords)) {
    // If any keyword matches, return that category
    if (keywords.some(keyword => lowerDesc.includes(keyword))) {
      return category;
    }
  }
  
  // Default fallback
  return 'Miscellaneous';
};

// Example calls:
categorizeTransaction("Paid Rs. 850 to Zomato") → "Food & Dining"
categorizeTransaction("Paid Rs. 1200 to Uber Cab") → "Travel"
categorizeTransaction("Random transaction") → "Miscellaneous"
```

### 2. Cashback Detection

```javascript
const detectCashback = (description) => {
  const lowerDesc = description.toLowerCase();
  
  // Check for explicit cashback keyword
  const hasCashbackKeyword = lowerDesc.includes('cashback');
  
  // Check if merchant is a known reward partner
  const isRewardPartner = rewardPartners.some(
    partner => lowerDesc.includes(partner)
  );
  
  // If either condition is true, calculate expected savings
  if (hasCashbackKeyword || isRewardPartner) {
    const savingsAmount = Math.floor(Math.random() * 500) + 50;
    return { 
      hasCashback: true, 
      savingsAmount: savingsAmount 
    };
  }
  
  return { 
    hasCashback: false, 
    savingsAmount: 0 
  };
};
```

### 3. Cumulative Metrics Reducer

```javascript
const calculateMetrics = (transactionsList) => {
  // Initialize metrics object
  const metrics = {
    'Food & Dining': { total: 0, count: 0 },
    'Travel': { total: 0, count: 0 },
    'Salary': { total: 0, count: 0 },
    'Shopping': { total: 0, count: 0 },
    'Miscellaneous': { total: 0, count: 0 },
  };

  // Process each transaction
  transactionsList.forEach(tx => {
    const category = tx.customCategory || tx.category;
    
    if (metrics[category]) {
      // Sum outgoing amounts (negative becomes positive)
      if (tx.amount < 0) {
        metrics[category].total += Math.abs(tx.amount);
      }
      
      // Count all transactions
      metrics[category].count += 1;
    }
  });

  return metrics;
};
```

### 4. Category Override Handler

```javascript
const updateCategory = (txId, newCategory) => {
  setTransactions(transactions.map(tx => 
    tx.id === txId 
      ? { ...tx, customCategory: newCategory }  // Store user override
      : tx
  ));
};

// When calculating metrics, customCategory takes precedence:
const category = tx.customCategory || tx.category;  // Override or auto
```

---

## 🎨 Frontend Components

### Component 1: Progress Bar
**Purpose**: Visualize spending per category
**Props**: category, amount, maxAmount

```
Input: Food & Dining, 1170, 5499
Output: [████████░░░░░░░░░░] 21% Rs. 1,170
```

**Algorithm**:
1. Calculate percentage: (amount / maxAmount) × 100
2. Animate bar expansion on new transactions
3. Update in real-time as metrics change

### Component 2: Transaction Card
**Purpose**: Display individual transaction with interactive controls
**Features**:
- Transaction description
- Amount (color-coded: green for income, black for expense)
- Category selector dropdown
- Cashback/Savings indicator (if applicable)
- Timestamp

### Component 3: Analytics Block
**Purpose**: Top-level spending overview
**Contains**:
- Progress bars for all categories
- Total spending metric
- Category breakdown

### Component 4: Transaction Stream
**Purpose**: Scrollable chronological timeline
**Features**:
- Newest transactions first
- Infinite scroll capability
- Smooth animations on new entries

---

## 📊 State Management

### React State Structure
```javascript
[transactions, setTransactions] = useState([
  {
    id: 1,
    description: "Paid Rs. 850 to Zomato",
    amount: -850,
    timestamp: Date,
    category: "Food & Dining",           // Auto-assigned
    customCategory: null,                // User override (if changed)
    hasCashback: true,                   // Detected
    savingsAmount: 125,                  // Calculated
  },
  // ... more transactions
]);
```

### State Updates
- **On new transaction**: Run categorizer → Run cashback detector → Add to state
- **On category change**: Update customCategory → Recalculate metrics
- **On user override**: customCategory takes priority over auto-assigned category

---

## 🔌 API Integration Points (Backend)

### Endpoint 1: Parse Transaction Alert
```
POST /api/transactions/parse
Input: { rawMessage: "Paid Rs. 850 to Zomato" }
Output: {
  description: "Paid Rs. 850 to Zomato",
  category: "Food & Dining",
  amount: -850,
  hasCashback: true,
  savingsAmount: 125
}
```

### Endpoint 2: Get User Metrics
```
GET /api/metrics
Query: ?timeRange=month&userId=123
Output: {
  totalSpending: 8269,
  categoryBreakdown: {
    "Food & Dining": { total: 1170, count: 2 },
    "Travel": { total: 1200, count: 1 },
    ...
  },
  insights: {
    topCategory: "Food & Dining",
    savingsOpportunity: 850
  }
}
```

### Endpoint 3: Update Transaction Category
```
PATCH /api/transactions/:id
Input: { category: "Shopping" }
Output: { success: true, transaction: {...} }
```

---

## 🚀 Scaling Considerations

### For High Volume
1. **Database Indexing**: Index on (userId, timestamp) for fast queries
2. **Caching**: Cache merchant keywords in Redis
3. **Batch Processing**: Process transaction streams in batches
4. **Async Jobs**: Off-load cashback calculations to background workers

### For Machine Learning Enhancement
1. Replace keyword matching with trained classifier
2. Predict category with confidence scores
3. Learn merchant aliases dynamically
4. Personalize cashback predictions per user

### For Real-Time Updates
1. WebSocket connections for live transaction streaming
2. Server-Sent Events (SSE) for analytics updates
3. Optimistic UI updates with offline support

---

## 📝 Implementation Checklist

- [x] Merchant keyword database
- [x] Auto-categorization logic
- [x] Cashback detection
- [x] Metrics aggregation
- [x] React frontend components
- [x] Category override handling
- [x] Expected savings display
- [ ] Backend API endpoints
- [ ] Database schema
- [ ] Authentication/Authorization
- [ ] Real-time transaction streaming
- [ ] Historical analytics
- [ ] Budget alerts
- [ ] Export reports (PDF/CSV)
- [ ] Mobile optimization

---

## 🔐 Security Considerations

1. **PII Protection**: Mask account numbers in transaction descriptions
2. **Rate Limiting**: Limit categorization API calls per user
3. **Data Validation**: Sanitize transaction descriptions
4. **Access Control**: Ensure users only see their transactions
5. **Encryption**: Encrypt transaction data in transit and at rest

---

## 📈 Future Enhancements

1. **Recurring Transaction Detection**: Identify subscription services
2. **Smart Budget Management**: AI-powered budget recommendations
3. **Multi-Account Support**: Aggregate across multiple bank accounts
4. **Export Capabilities**: Generate monthly/yearly reports
5. **Tax Optimization**: Categorize for tax deduction purposes
6. **Comparison Analytics**: Benchmark spending vs. similar users
7. **Bill Splitting**: Integration with split payment services
8. **Investment Tracking**: Monitor investment-related transactions
